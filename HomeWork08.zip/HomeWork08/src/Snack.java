public enum Snack {
    CHIPS, CRACKERS, TWIX, SNICKERS
}
