import java.util.Scanner;

//Создайте перечисление для угощений в снек-автомате (3-4 позиции).
//Пользователь вводит номер снека.
// Программа должна вывести название снека, который выдал автомат.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите номер снека: ");
        int userNum = scn.nextInt() -1;
        String snackName = null;
        if (Snack.CHIPS.ordinal() == userNum){
            snackName = Snack.CHIPS.name();
        }
        if (Snack.CRACKERS.ordinal() == userNum){
            snackName = Snack.CRACKERS.name();
        }
        if (Snack.TWIX.ordinal() == userNum){
            snackName = Snack.TWIX.name();
        }
        if (Snack.SNICKERS.ordinal() == userNum){
            snackName = Snack.SNICKERS.name();
        }
        System.out.println("Название снека " + snackName);

    }
}